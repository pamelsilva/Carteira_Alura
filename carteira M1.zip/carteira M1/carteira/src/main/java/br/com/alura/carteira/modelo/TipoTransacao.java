package br.com.alura.carteira.modelo;

public enum TipoTransacao {

	COMPRA,
	VENDA;
	
}
